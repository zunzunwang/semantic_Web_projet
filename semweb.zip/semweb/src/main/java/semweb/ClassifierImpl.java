package semweb;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Collection;

import org.semarglproject.jena.rdf.rdfa.JenaRdfaReader;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class ClassifierImpl  implements Classifier  {

	protected ClassifierImpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	public Collection<String> retrieveTypes(String iri) {
		// TODO Auto-generated method stub
		JenaRdfaReader.inject();
		Model m = null;
		try {
			m = ModelFactory.createDefaultModel();
			m.read(iri,"TTL");			
		} catch ( org.apache.jena.riot.RiotException e) {
			// TODO Auto-generated catch block			
			try {
				m = ModelFactory.createDefaultModel();
				m.read(iri,"RDF/XML");				
				} catch ( org.apache.jena.riot.RiotException a) {
					// TODO Auto-generated catch block
					try {
						m = ModelFactory.createDefaultModel();
						m.read(iri,"RDFA");	
						} catch ( org.apache.jena.riot.RiotException c) {
							c.printStackTrace();							
						}
					}
			}finally{
				m.write(System.out);
			}
					
		return null;
	}

	public Collection<String> retrieveSuperClasses(String iri) {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<String> getAllTypes(String url) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isOfType(String entityIRI, String classIRI) {
		// TODO Auto-generated method stub
		return false;
	}

}
